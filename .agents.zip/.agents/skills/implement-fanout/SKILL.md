---
name: implement-fanout
description: >-
  Decomposes complex multi-part features into parallel sub-tasks or subagents in isolated workspaces/worktrees, runs full build/test verification, and merges to main only after user approval. Use when implementing large features, multi-file refactors, or when isolated sandbox execution is required.
---

# Implement Fan-Out Skill

This skill implements features in an **isolated sandbox / Git worktree** to keep the main codebase clean and safe. It breaks complex tasks into modular sub-tasks (fan-out), runs automated tests/builds, and merges changes to the main branch **only after the user reviews and approves**.

---

## 🔒 Golden Rules
1. **Never touch the main branch directly** for major features or refactors.
2. **User controls the decision**: Present architectural options and diffs before merging.
3. **Automated Gate**: All unit tests, static analysis (PHPStan / Psalm), and code-style checks (PHP-CS-Fixer / Laravel Pint) must pass in the sandbox before requesting merge approval.

---

## Workflow Steps

### 1. Architectural Plan & Fan-Out Decomposition
- Break the feature down into 3-5 modular components:
  - Example (Laravel): `1. Form Request / DTO & Validation` -> `2. Service & Business Logic` -> `3. Controller & Routes` -> `4. Feature / Unit Tests`.
  - Example (Symfony): `1. DTO & Validator constraints` -> `2. Repository & Entity (Doctrine)` -> `3. Service` -> `4. Controller & Routing`.
- Present the plan to the user and confirm any design choices (e.g., ORM, error codes, naming).

### 2. Create Isolated Sandbox (Git Worktree / Branch)
Create a temporary working branch or git worktree:
```bash
git checkout -b feature/<feature-name>-sandbox
# Or use a dedicated worktree:
# git worktree add ../feature-sandbox -b feature/<feature-name>
```

### 3. Step-by-Step Implementation & Fan-Out
- Implement each component in the sandbox.
- If using subagents for large independent tasks, launch subagents with `Workspace: branch` or `Workspace: share` so they work in isolated workspaces.
- Explain each major step to the user, highlighting key concepts or asking for input on critical trade-offs.

### 4. Automated Verification Gate & Comprehensive Testing
In the sandbox environment, execute:
```bash
composer install
vendor/bin/phpunit --testsuite=Unit      # or: php artisan test --testsuite=Unit
vendor/bin/phpunit --testsuite=Feature   # or: php artisan test --testsuite=Feature
vendor/bin/phpstan analyse               # static analysis, if configured
vendor/bin/pint --test                   # or vendor/bin/php-cs-fixer fix --dry-run
```
- **Testing Requirement**: Ensure Unit Tests cover the business logic (Services/Use Cases) and Feature Tests cover the API endpoints (Controllers).
- If any build or test errors occur, fix them inside the sandbox automatically.
- Do NOT proceed to merge until the sandbox passes cleanly with zero errors across BOTH unit and feature test suites.

### 5. Review & User Approval
Present a clean summary to the user:
- Summary of changes made.
- Verification results (tests: ✅, static analysis: ✅, code style: ✅).
- Key files changed.
- Ask: *"Barcha testlar muvaffaqiyatli o'tdi. O'zgarishlarni asosiy (main) branchga o'tkazishni (merge) tasdiqlaysizmi?"*

### 6. Merge & Cleanup
Upon user confirmation:
- Switch back to main/working branch and merge:
  ```bash
  git checkout main (or original branch)
  git merge feature/<feature-name>-sandbox
  git branch -d feature/<feature-name>-sandbox
  ```
- If a worktree was used, remove it: `git worktree remove ../feature-sandbox`.
