---
name: teach
description: >-
  Creates and manages an interactive, stateful teaching environment to learn concepts, frameworks, libraries, or algorithms deeply. Use when the user wants to learn or master a topic (e.g. "/teach Laravel Middleware", "/teach Symfony Dependency Injection"), requests structured lessons, or needs interactive exercises with persistent progress tracking.
---

# Teach Skill

This skill turns your active project into a **stateful, long-term learning environment**. Instead of giving quick, forgettable answers, it structures learning into persistent modules directly within your project directory, tracks mastery across sessions, and ensures deep conceptual understanding through active practice.

---

## 📍 File Storage Policy (Project-Local)

**CRITICAL RULE**: All teaching materials, lessons, and records MUST be created and stored directly inside the active project codebase under the `teach/` folder (or `.teach/` folder):

```text
<workspace_root>/teach/
├── MISSION.md             # The learning roadmap, active topic, and goals checklist
├── RESOURCES.md           # High-trust official docs, guides, and source references
├── lessons/               # Sequential interactive lessons with runnable code examples
│   ├── 01-intro.md
│   ├── 02-deep-dive.md
│   └── ...
└── learning-records/      # Record of mastered concepts and personal notes (like ADRs)
    ├── LR-001-core-concept.md
    └── ...
```

*(Ensure `<workspace_root>/teach/` and subfolders are automatically created inside the active project).*

---

## Workflow Steps

### 1. Initialize or Load State in Project
- **Check existing files**: Look inside the project's `teach/` directory for `MISSION.md` and `learning-records/`.
- If starting a **new topic**:
  - Ask the user about their current experience level and specific goal if not already clear.
  - Create `teach/MISSION.md` outlining the structured roadmap (e.g., 3-5 progressive modules).
  - Create `teach/RESOURCES.md` with official documentation and authoritative references (e.g. laravel.com/docs, symfony.com/doc, php.net manual).
- If **resuming**:
  - Read `teach/MISSION.md` and recent entries in `teach/learning-records/` to identify the active module and next lesson.

### 2. Deliver Progressive, Bite-Sized Lessons
- Teach **one concept at a time** (avoid overwhelming information dumps).
- Structure each lesson inside `teach/lessons/<number>-<topic>.md`:
  1. **Concept Explanation**: Clear, real-world analogy and high-level architectural overview.
  2. **Code Demonstration**: Concrete, runnable PHP code snippets directly compatible with the active project.
  3. **Under the Hood**: Why it works this way and common pitfalls / anti-patterns.

### 3. Active Engagement & Verification
- After explaining the concept, present an **interactive challenge or quiz**:
  - Code refactoring task in the active project,
  - Bug detection exercise, or
  - Concept check questions.
- Ask the user to solve or respond before moving to the next topic.

### 4. Record Mastery
- When the user understands or completes the exercise:
  - Create a note in `teach/learning-records/LR-<number>-<topic>.md` summarizing the core takeaway.
  - Update `teach/MISSION.md` checking off the completed goal (`[x]`).
  - Introduce the next topic on the roadmap.
