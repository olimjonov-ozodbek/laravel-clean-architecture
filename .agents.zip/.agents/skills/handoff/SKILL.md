---
name: handoff
description: >-
  Compacts the current conversation, task progress, and workspace state into a single portable markdown handoff document. Use when the user asks for a handoff, pauses a coding/grilling session, needs to switch to another workspace/agent, or wants to preserve context without losing progress.
---

# Handoff Skill

This skill captures and compacts the full context of the current session into a portable, structured handoff document. It allows you or another agent in a future session to pick up work seamlessly without losing context or cluttering the conversation history.

---

## 📍 File Storage Policy (Project-Local)

**CRITICAL RULE**: All handoff documents MUST be saved directly inside the current active project codebase (workspace root), NEVER in temporary OS folders or external directories.

- **Primary Location**: `<workspace_root>/docs/handoffs/handoff-<YYYY-MM-DD-HHmm>.md`
- **Alternative / Quick Location**: `<workspace_root>/.handoff.md`

*(Automatically create the `docs/handoffs/` folder inside the project if it does not exist).*

---

## Workflow Steps

### 1. Gather Current Session Context
Review the entire conversation and recent workspace changes:
- **Primary Objective**: What was the user trying to accomplish?
- **Current State**: What has been completed? What is currently in progress?
- **Key Decisions & Architecture**: What choices, tradeoffs, or constraints were established (e.g. Laravel vs Symfony, Eloquent vs Doctrine)?
- **Modified & Created Files**: List the critical files with clickable links and brief summaries of changes.
- **Errors & Blockers**: Any unresolved errors, edge cases, or pending bugs.
- **Next Steps**: Exact checklist of what the next agent or session should execute.

### 2. Generate the Handoff Document
Create the markdown file directly inside the project directory using this template:

```markdown
# Handoff: [Task / Feature Name]
**Date & Time**: [YYYY-MM-DD HH:mm]
**Project**: [Current project name]

## 1. Mission & Objectives
- **Goal**: [Brief summary of the goal]
- **Status**: [Completed / In Progress / Blocked]

## 2. Completed Work & Key Decisions
- [Decision 1 / Work completed]
- [Decision 2 / Work completed]

## 3. Touched Files
- `[app/...]`: [Summary of changes]

## 4. Current Blockers / Unresolved Items
- [Issue or blocker, if any]

## 5. Immediate Next Steps (Checklist for Next Session)
- [ ] [Step 1]
- [ ] [Step 2]
- [ ] [Step 3]

## 6. How to Resume
Read this file and continue from Step 1 above.
```

### 3. Report to the User
Provide a concise summary and a clickable file link to the generated document in the project:
- E.g.: `[docs/handoffs/handoff-2026-08-26-1100.md](file:///d:/php/laravel-app/docs/handoffs/handoff-2026-08-26-1100.md)`
- Highlight the immediate next step.
