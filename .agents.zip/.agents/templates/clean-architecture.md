# Clean Architecture & Clean Code Templates (PHP — Laravel / Symfony)

This document defines the strict architectural boundaries the AI must follow when scaffolding new features for the user.

## Core Principles
1. **Dependency Rule**: Dependencies must point INWARD toward business entities and use cases.
2. **Separation of Concerns**: Controllers handle HTTP, Services/Use Cases handle business logic, Repositories handle data access.
3. **Validation at the Edge**: DTOs / Form Requests must strictly validate incoming data before it reaches the domain layer.

---

## 1. DTO & Validation Layer (Edge)
**Goal**: Filter and validate data before it enters the application.

```php
<?php
// src/Example/Dto/CreateExampleDto.php

declare(strict_types=1);

namespace App\Example\Dto;

final class CreateExampleDto
{
    public function __construct(
        public readonly string $title,
    ) {
    }

    /**
     * Build the DTO from raw validated array data.
     */
    public static function fromArray(array $data): self
    {
        return new self(
            title: (string) $data['title'],
        );
    }
}
```

Laravel-style validation is typically done via a dedicated **Form Request**:

```php
<?php
// app/Http/Requests/CreateExampleRequest.php

declare(strict_types=1);

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

final class CreateExampleRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'title' => ['required', 'string', 'max:100'],
        ];
    }
}
```

## 2. Domain Entity Layer (Core)
**Goal**: Define the pure business objects independent of any framework or database.

```php
<?php
// src/Example/Domain/ExampleEntity.php

declare(strict_types=1);

namespace App\Example\Domain;

final class ExampleEntity
{
    public function __construct(
        public readonly string $id,
        public string $title,
        public readonly \DateTimeImmutable $createdAt,
    ) {
    }

    // Domain logic methods can go here
    public function changeTitle(string $newTitle): void
    {
        $this->title = $newTitle;
    }
}
```

## 3. Repository Interface (Boundary)
**Goal**: Define how data is accessed without implementing the database logic (Dependency Inversion).

```php
<?php
// src/Example/Domain/ExampleRepositoryInterface.php

declare(strict_types=1);

namespace App\Example\Domain;

interface ExampleRepositoryInterface
{
    public function save(ExampleEntity $entity): void;

    public function findById(string $id): ?ExampleEntity;
}
```

## 4. Use Case / Service Layer (Application Logic)
**Goal**: Orchestrate business rules using interfaces. Must not know about HTTP.

```php
<?php
// src/Example/Application/ExampleService.php

declare(strict_types=1);

namespace App\Example\Application;

use App\Example\Domain\ExampleEntity;
use App\Example\Domain\ExampleRepositoryInterface;
use App\Example\Dto\CreateExampleDto;

final class ExampleService
{
    public function __construct(
        private readonly ExampleRepositoryInterface $repository,
    ) {
    }

    public function executeCreate(CreateExampleDto $dto): ExampleEntity
    {
        $entity = new ExampleEntity(
            id: \bin2hex(\random_bytes(16)), // yoki Ramsey\Uuid::uuid4()->toString()
            title: $dto->title,
            createdAt: new \DateTimeImmutable(),
        );

        $this->repository->save($entity);

        return $entity;
    }
}
```

## 5. Controller Layer (Delivery)
**Goal**: Handle HTTP requests, pass data to Use Cases, and return HTTP responses.

Laravel example:

```php
<?php
// app/Http/Controllers/ExampleController.php

declare(strict_types=1);

namespace App\Http\Controllers;

use App\Example\Application\ExampleService;
use App\Example\Dto\CreateExampleDto;
use App\Http\Requests\CreateExampleRequest;
use Illuminate\Http\JsonResponse;

final class ExampleController extends Controller
{
    public function __construct(
        private readonly ExampleService $exampleService,
    ) {
    }

    public function store(CreateExampleRequest $request): JsonResponse
    {
        $dto = CreateExampleDto::fromArray($request->validated());

        $entity = $this->exampleService->executeCreate($dto);

        return response()->json($entity, 201);
    }
}
```

Symfony example (using attribute routing):

```php
<?php
// src/Controller/ExampleController.php

declare(strict_types=1);

namespace App\Controller;

use App\Example\Application\ExampleService;
use App\Example\Dto\CreateExampleDto;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Attribute\Route;

final class ExampleController
{
    public function __construct(
        private readonly ExampleService $exampleService,
    ) {
    }

    #[Route('/example', name: 'example_create', methods: ['POST'])]
    public function create(Request $request): JsonResponse
    {
        $data = \json_decode($request->getContent(), true);
        $dto = CreateExampleDto::fromArray($data);

        $entity = $this->exampleService->executeCreate($dto);

        return new JsonResponse($entity, 201);
    }
}
```

---

## Testing Strategy Requirements
When implementing features, the AI must write:
1. **Unit Tests (`tests/Unit/...Test.php`)**: For the `ExampleService` (Use Cases), mocking the `ExampleRepositoryInterface` (e.g. with PHPUnit's `createMock()` or Mockery). This verifies pure business logic.
2. **Feature / E2E Tests (`tests/Feature/...Test.php`)**: For the `ExampleController`, booting the application kernel (Laravel's `TestCase` / Symfony's `WebTestCase`) and hitting endpoints to verify the full HTTP flow and validation.

```php
<?php
// tests/Unit/ExampleServiceTest.php

declare(strict_types=1);

namespace Tests\Unit;

use App\Example\Application\ExampleService;
use App\Example\Domain\ExampleRepositoryInterface;
use App\Example\Dto\CreateExampleDto;
use PHPUnit\Framework\TestCase;

final class ExampleServiceTest extends TestCase
{
    public function test_it_creates_and_saves_an_entity(): void
    {
        $repository = $this->createMock(ExampleRepositoryInterface::class);
        $repository->expects($this->once())->method('save');

        $service = new ExampleService($repository);
        $entity = $service->executeCreate(new CreateExampleDto(title: 'Test'));

        $this->assertSame('Test', $entity->title);
    }
}
```
